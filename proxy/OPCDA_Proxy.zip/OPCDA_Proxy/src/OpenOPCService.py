###########################################################################
#
# OpenOPC Gateway Service
#
# A Windows service providing remote access to the OpenOPC library.
#
# Copyright (c) 2007-2014 Barry Barnreiter (barry_b@users.sourceforge.net)
#
###########################################################################

import win32serviceutil
import win32service
import win32event
import servicemanager
import winerror
import winreg
import select
import socket
import os
import sys
import time
import threading
import OpenOPC
import json

try:
    import Pyro4.core
    import Pyro4.errors
    Pyro4.config.SERVERTYPE='thread'
except ImportError:
    print('Pyro4 module required (https://pypi.python.org/pypi/Pyro4)')
    exit()

# Default var value
opc_class           = OpenOPC.OPC_CLASS

opc_gate_host       = None
opc_gate_port       = 7766

inactive_timeout    = 60
max_clients         = 25

def getvar(env_var):
    """Read system enviornment variable from registry"""
    try:
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, 'SYSTEM\\CurrentControlSet\\Control\Session Manager\Environment',0,winreg.KEY_READ)
        value, valuetype = winreg.QueryValueEx(key, env_var)
        return value
    except:
        return None

# Get env vars directly from the Registry since a reboot is normally required for the Local System account to inherit these.
if getvar('OPC_CLASS'): 
    opc_class = getvar('OPC_CLASS')

if getvar('OPC_GATE_HOST'):
    opc_gate_host = getvar('OPC_GATE_HOST')
    if opc_gate_host.strip() in ('0.0.0.0', ''):
        opc_gate_host = None

if getvar('OPC_GATE_PORT'):  
    opc_gate_port = int(getvar('OPC_GATE_PORT'))

if getvar('OPC_MAX_CLIENTS'): 
    max_clients = int(getvar('OPC_MAX_CLIENTS'))

if getvar('OPC_INACTIVE_TIMEOUT'): 
    inactive_timeout = int(getvar('OPC_INACTIVE_TIMEOUT'))

def inactive_cleanup(exit_event):
    while True:
        exit_event.wait(60.0)

        if exit_event.is_set():
            try:
                all_sessions = OpenOPC.get_sessions(host=opc_gate_host, port=opc_gate_port)
                for server, oid, ctime, xtime in all_sessions:
                    OpenOPC.close_session(oid, host=opc_gate_host, port=opc_gate_port)
            except Exception as e:
                servicemanager.LogInfoMsg('\n\nException %s happen when stop opc gateway service' % e)
            finally:
                exit_event.clear()
            return
        else:
            try:
                all_sessions = OpenOPC.get_sessions(host=opc_gate_host, port=opc_gate_port)
                if len(all_sessions) > max_clients:
                    stale_sessions = sorted(all_sessions, key=lambda s: s[3])[:-max_clients]
                else:

                    stale_sessions = [s for s in all_sessions if time.time() - s[3] > (inactive_timeout * 60)]
                for server, oid, ctime, xtime in stale_sessions:
                    OpenOPC.close_session(oid, host=opc_gate_host, port=opc_gate_port)
                    time.sleep(1)
            except Exception as e:
                servicemanager.LogInfoMsg('\n\nException %s happen when cleanup timeout session' % e)

@Pyro4.expose
class opc(object):
    def __init__(self):
        self._opc_objects   = {}
        self._init_times    = {}
        self._last_times    = {}

    def get_clients(self):
        """Return list of server instances as a hash of GUID:host"""
        hlist = []

        reg1 = self._pyroDaemon.objectsById.keys()
        reg2 = [obj for obj in reg1 if obj.find('obj_') == 0]
        if not reg2:
            return hlist

        reg = ["PYRO:{0}@{1}:{2}".format(obj, opc_gate_host, opc_gate_port) for obj in reg2]
        init_times  = self._init_times
        last_times  = self._last_times
        opc_objects = self._opc_objects
        hlist = [(opc_objects[k].opc_server, k, init_times[k], last_times[k]) for k in reg]

        return hlist

    def create_client(self):
        """Create a new OpenOPC client instance in the Pyro server"""

        opc_obj = OpenOPC.client(opc_class)
        opc_obj._open_serv = self
        opc_obj._open_self = opc_obj
        opc_obj._open_host = opc_gate_host
        opc_obj._open_port = opc_gate_port

        uri = self._pyroDaemon.register(opc_obj)
        opc_obj._open_guid = uri.asString()

        self._opc_objects[opc_obj._open_guid] = opc_obj
        self._init_times[opc_obj._open_guid] =  time.time()
        self._last_times[opc_obj._open_guid] =  time.time()

        servicemanager.LogInfoMsg('\n\nCreate client %s' % opc_obj._open_guid)

        return Pyro4.Proxy(uri)

    def release_client(self, obj):
        """Release a OpenOPC client instance in the Pyro server"""

        try:
            guid = obj.GUID()
            self._pyroDaemon.unregister(obj)
        except Exception as e:
            servicemanager.LogInfoMsg('\n\nException %s happen when unregister client %s from Pyro daemon' % (e, guid))
        finally:
            del self._opc_objects[guid]
            del self._init_times[guid]
            del self._last_times[guid]

        servicemanager.LogInfoMsg('\n\nDestroy client %s' % guid)

    def force_close(self, guid):
        """Force release a OpenOPC client instance in the Pyro server"""

        obj = self._opc_objects[guid]
        if obj:
            self.release_client(obj)

        servicemanager.LogInfoMsg('\n\nForcing destroy client %s' % guid)

class OpcService(win32serviceutil.ServiceFramework):
    _svc_name_ = "zzzOpenOPCService"
    _svc_display_name_ = "OpenOPC Gateway Service"
    
    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)
    
    def SvcStop(self):
        servicemanager.LogInfoMsg('\n\nStopping service')
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.hWaitStop)

    def SvcDoRun(self):
        servicemanager.LogInfoMsg('\n\nStarting service\nOPC_GATE_HOST=%s\nOPC_GATE_PORT=%d\nOPC_MAX_CLIENTS=%d\nOPC_INACTIVE_TIMEOUT=%d' % ('localhost' if opc_gate_host is None else opc_gate_host, opc_gate_port, max_clients, inactive_timeout))

        exit_event = threading.Event()
        p = threading.Thread(target=inactive_cleanup, args=(exit_event,))
        p.start()

        daemon = Pyro4.core.Daemon(host=opc_gate_host, port=opc_gate_port)
        uri = daemon.register(opc(), "opc")
        servicemanager.LogInfoMsg("\n\nStartup opc pyro daemon(%s)" % uri.asString())

        stop_pending = False
        while True:
            if not stop_pending and win32event.WaitForSingleObject(self.hWaitStop, 0) == win32event.WAIT_OBJECT_0:
                exit_event.set()
                stop_pending = True
            elif stop_pending and not exit_event.is_set():
                break
    
            socks = daemon.sockets
            ins,outs,exs = select.select(socks,[],[],1)
            for s in socks:
                if s in ins:
                    daemon.events(ins)
                    break

        p.join()
        daemon.shutdown()

if __name__ == '__main__':
    if len(sys.argv) == 1:
        try:
            evtsrc_dll = os.path.abspath(servicemanager.__file__)
            servicemanager.PrepareToHostSingle(OpcService)
            servicemanager.Initialize('zzzOpenOPCService', evtsrc_dll)
            servicemanager.StartServiceCtrlDispatcher()
        except win32service.error as details:
            if details[0] == winerror.ERROR_FAILED_SERVICE_CONTROLLER_CONNECT:
                win32serviceutil.usage()
    else:
        win32serviceutil.HandleCommandLine(OpcService)
